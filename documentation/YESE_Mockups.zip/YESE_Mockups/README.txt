YESE Mockups
============

Open index.html in a web browser (Chrome, Edge, Firefox or Safari).
Keep the "assets" folder next to the HTML files.

Screens:
  01-sign-in.html  01 · Sign in
  02-super-admin-tenants.html  02 · Super Admin · Tenants
  03-super-admin-module-activation.html  03 · Super Admin · Module activation
  04-school-admin-dashboard.html  04 · School Admin · Dashboard
  05-school-admin-roles-and-permissions.html  05 · School Admin · Roles & permissions
  06-school-admin-academic-structure.html  06 · School Admin · Academic structure
  07-school-admin-students.html  07 · School Admin · Students
  08-school-admin-enrollment.html  08 · School Admin · Enrollment
  09-teacher-attendance-register.html  09 · Teacher · Attendance register
  10-teacher-mark-entry.html  10 · Teacher · Mark entry
  11-exam-officer-validate-and-lock.html  11 · Exam Officer · Validate & lock
  12-report-card-pdf-a4.html  12 · Report card (PDF, A4)
  13-student-results-phone.html  13 · Student · Results (phone)
  14-parent-portal-phone-stretch.html  14 · Parent portal (phone, stretch)
  15-bursar-invoices-and-payments-stretch.html  15 · Bursar · Invoices & payments (stretch)
