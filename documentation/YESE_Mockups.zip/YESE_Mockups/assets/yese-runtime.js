/* Minimal standalone renderer for the exported YESE mockup screens.
   Renders {{holes}}, <template data-sc="for|if">, event bindings and state updates. */
(function () {
  function lookup(scope, path) {
    path = path.trim();
    if (path === 'true') return true;
    if (path === 'false') return false;
    if (/^-?\d+(\.\d+)?$/.test(path)) return Number(path);
    if (/^'.*'$|^".*"$/.test(path)) return path.slice(1, -1);
    var parts = path.split('.');
    var v = scope;
    for (var i = 0; i < parts.length; i++) {
      if (v == null) return undefined;
      v = v[parts[i]];
    }
    return v;
  }
  var WHOLE = /^\s*\{\{\s*([^}]+?)\s*\}\}\s*$/;
  var ANY = /\{\{\s*([^}]+?)\s*\}\}/g;
  function interp(str, scope) {
    return str.replace(ANY, function (_, p) { var v = lookup(scope, p); return v == null ? '' : String(v); });
  }
  var EVENTS = { onclick: 'click', onchange: 'change', oninput: 'input', onsubmit: 'submit' };

  function renderNodes(nodes, scope, out) {
    for (var i = 0; i < nodes.length; i++) renderNode(nodes[i], scope, out);
  }
  function renderNode(node, scope, out) {
    if (node.nodeType === 3) { out.push(document.createTextNode(interp(node.nodeValue, scope))); return; }
    if (node.nodeType !== 1) return;
    var tag = node.localName;
    if (tag === 'template' && node.getAttribute('data-sc') === 'for') {
      var list = lookup(scope, (node.getAttribute('list').match(WHOLE) || [0, ''])[1]) || [];
      var as = node.getAttribute('as') || 'item';
      for (var k = 0; k < list.length; k++) {
        var s = Object.create(scope); s[as] = list[k]; s.$index = k;
        renderNodes(node.content.childNodes, s, out);
      }
      return;
    }
    if (tag === 'template' && node.getAttribute('data-sc') === 'if') {
      var cond = lookup(scope, (node.getAttribute('value').match(WHOLE) || [0, 'false'])[1]);
      if (cond) renderNodes(node.content.childNodes, scope, out);
      return;
    }
    var el = node.namespaceURI && node.namespaceURI !== 'http://www.w3.org/1999/xhtml'
      ? document.createElementNS(node.namespaceURI, node.tagName)
      : document.createElement(tag);
    var props = {};
    for (var a = 0; a < node.attributes.length; a++) {
      var at = node.attributes[a], name = at.name, val = at.value;
      if (name.indexOf('hint-') === 0) continue;
      var m = val.match(WHOLE);
      var raw = m ? lookup(scope, m[1]) : undefined;
      if (EVENTS[name]) {
        if (typeof raw === 'function') {
          var evt = EVENTS[name];
          if (name === 'onchange' && (tag === 'input' || tag === 'textarea')) evt = (node.getAttribute('type') === 'checkbox') ? 'change' : 'input';
          el.addEventListener(evt, (function (fn) { return function (e) { fn(e); }; })(raw));
        }
        continue;
      }
      if (m && (name === 'value' || name === 'checked' || name === 'disabled')) { props[name] = raw; continue; }
      if (m && typeof raw === 'boolean' && name.indexOf('aria-') !== 0) { if (raw) el.setAttribute(name, ''); continue; }
      el.setAttribute(name, m ? (raw == null ? '' : String(raw)) : interp(val, scope));
    }
    var kids = [];
    renderNodes((tag === 'template' ? node.content : node).childNodes, scope, kids);
    for (var c = 0; c < kids.length; c++) el.appendChild(kids[c]);
    if ('value' in props) el.value = props.value == null ? '' : props.value;
    if ('checked' in props) el.checked = !!props.checked;
    if ('disabled' in props) el.disabled = !!props.disabled;
    out.push(el);
  }

  function DCLogic(props) { this.props = props || {}; this.state = {}; }
  DCLogic.prototype.setState = function (patch) {
    var next = typeof patch === 'function' ? patch(this.state) : patch;
    this.state = Object.assign({}, this.state, next);
    if (this.__render) this.__render();
  };
  DCLogic.prototype.forceUpdate = function () { if (this.__render) this.__render(); };
  window.DCLogic = DCLogic;

  function boot() {
    var tpl = document.getElementById('dc-template');
    var root = document.getElementById('dc-root');
    var src = document.querySelector('script[data-dc-script]');
    var Component = new Function('DCLogic', src.textContent + '\n;return Component;')(DCLogic);
    var inst = new Component({});
    if (!inst.state) inst.state = {};
    inst.__render = function () {
      var active = document.activeElement, id = active && active.id, s0, s1;
      try { s0 = active.selectionStart; s1 = active.selectionEnd; } catch (e) {}
      var out = [];
      renderNodes(tpl.content.childNodes, inst.renderVals(), out);
      root.replaceChildren.apply(root, out);
      if (id) {
        var again = document.getElementById(id);
        if (again) { again.focus(); try { if (s0 != null) again.setSelectionRange(s0, s1); } catch (e) {} }
      }
    };
    inst.__render();
    if (inst.componentDidMount) inst.componentDidMount();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
